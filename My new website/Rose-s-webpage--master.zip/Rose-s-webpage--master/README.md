# Rose's webpage fostering.-
Fostering puppys and animals.

Hello my name is Rose Coleman.

welcome to my webpage, everyone is welcomed on this page.

On this webpage/site we are welcome to foster puppys, each puppy up to 2-4 weeks can you foster them but you must be 18 years of age to foster puppys or any animals.

Each puppy cost around $45 including the veteriary case, food and other supplies the dog might need.

We bread any kind of dog and it'll stay with it's parents up to 2-4 weeks then you can foster them.
